import React, { useEffect } from 'react'
import { connect } from 'react-redux'
import classes from './Injury.module.css'
import { getInjury } from '../../store/actions/injuryactions'
const Injury = props => {
	useEffect(() => {
		//fire an action to the backend to get the injury data
		props.getInjury(props.homeId, props.awayId)
	}, [props.homeId, props.awayId])
	return (
		<div>
			{props.injury.loading ? null : (
				<div className={classes.container}>
					<div className={classes.playHeader}>
						<h1>INJURY REPORT</h1>
					</div>
					<div className={classes.homeContainer}>
						<img
							className={classes.image}
							src={props.teams.homeTeam.logos.small}
						/>
						<div className={classes.smallerContainer}>
							<div className={classes.title}>
								{props.teams.homeTeam.full_name}
							</div>
							<div>
								<table>
									<thead>
										<th>Name</th>
										<th>Status</th>
									</thead>
									<tbody>
										{props.injury.homeInjury.map((item, index) => {
											return (
												<tr key={index}>
													<td>{item.player.first_initial_and_last_name}</td>
													<td>{item.status}</td>
												</tr>
											)
										})}
									</tbody>
								</table>
							</div>
						</div>
					</div>
					<div className={classes.homeContainer}>
						<img
							className={classes.image}
							src={props.teams.awayTeam.logos.small}
						/>
						<div className={classes.smallerContainer}>
							<div className={classes.title}>
								{props.teams.awayTeam.full_name}
							</div>
							<div>
								<table>
									<thead>
										<th>Name</th>
										<th>Status</th>
									</thead>
									<tbody>
										{props.injury.awayInjury.map((item, index) => {
											return (
												<tr key={index}>
													<td>{item.player.first_initial_and_last_name}</td>
													<td>{item.status}</td>
												</tr>
											)
										})}
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			)}
		</div>
	)
}
const mapStateToProps = state => ({
	teams: state.team,
	injury: state.injury
})
const mapDispatchToProps = { getInjury }
export default connect(mapStateToProps, mapDispatchToProps)(Injury)
