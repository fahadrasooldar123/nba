import React, { useEffect, useState } from 'react'
import { connect } from 'react-redux'
import classes from './RecnentPlay.module.css'
import { getPrev } from '../../store/actions/index'
const RecentPlay = props => {
	useEffect(() => {
		props.getPrev(props.homeId, props.awayId)
		// claculate win/looss
	}, [props.homeId, props.awayId])
	const awayWinCalc = APD => {
		let awayWinString = ''
		APD.forEach(item => {
			const result2 =
				item.box_score.score.home.score - item.box_score.score.away.score
			if (result2 > 0) {
				awayWinString = awayWinString.concat('W')
			} else {
				awayWinString = awayWinString.concat('L')
			}
		})
		return awayWinString
	}
	const calcWin = HPD => {
		let homeWinString = ''

		HPD.forEach(item => {
			const result =
				item.box_score.score.home.score - item.box_score.score.away.score

			if (result > 0) {
				homeWinString = homeWinString.concat('W')
			} else {
				homeWinString = homeWinString.concat('L')
			}
		})

		return homeWinString
	}
	return (
		<>
			{props.prev.loading ? null : (
				<div className={classes.container}>
					<div className={classes.playHeader}>
						<h1>RECENT PLAY</h1>
					</div>
					<div className={classes.smallContainer}>
						<div className={classes.homeContainer}>
							<h1 style={{ fontSize: '2rem' }}>Previous Three Games</h1>
							<div className={classes.boxScore}>
								{/* arary ko box_score.score.home.score and array ko box_score.score.away.score */}
								{props.prev.HPD.slice(0, 3).map((item, index) => {
									return (
										<div
											key={index}
											style={{ display: 'inline-block', margin: '0 50px' }}
										>
											<h1>LAL</h1>
											<h1>
												{item.box_score.score.home.score}-
												{item.box_score.score.away.score}
											</h1>
											<div>Box-Score</div>
										</div>
									)
								})}
								<div className={classes.prev}>
									<h1>Previous Match History</h1>
									<h2>{awayWinCalc(props.prev.APD)}</h2>
								</div>
							</div>
						</div>
						<div className={classes.awayContainer}>
							{' '}
							<h1 style={{ fontSize: '2rem' }}>Previous Three Games</h1>
							<div className={classes.boxScore}>
								{/* arary ko box_score.score.home.score and array ko box_score.score.away.score */}
								{props.prev.APD.slice(0, 3).map(item => (
									<div style={{ display: 'inline-block', margin: '0 50px' }}>
										<h1>LAL</h1>
										<h1>
											{item.box_score.score.home.score}-
											{item.box_score.score.away.score}
										</h1>
										<div style={{ textDecoration: 'underline' }}>Box-Score</div>
									</div>
								))}
								<div className={classes.prev}>
									<h1>Previous Match History</h1>
									<h2>{calcWin(props.prev.HPD)}</h2>
								</div>
							</div>
						</div>
					</div>
				</div>
			)}
		</>
	)
}
const mapStateToProps = state => ({
	prev: state.prev
})
const mapDispatchToProps = {
	getPrev
}
export default connect(mapStateToProps, mapDispatchToProps)(RecentPlay)
