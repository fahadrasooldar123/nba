import React, { useEffect } from 'react'
import { connect } from 'react-redux'
import Injury from '../Injury/Injury'

import Players from '../Players/Players'
import RecentPlay from '../RecentPlay/RecentPlay'
import classes from './MatchUp.module.css'
const MatchUp = props => {
	const loadable = () => {
		return (
			<>
				<div className={classes.container}>
					<img
						className={classes.image}
						src={props.teams.homeTeam.logos.large}
					/>
					<div className={classes.middleText}>
						<div className={classes.versusText}>
							{props.teams.homeTeam.full_name} VS{' '}
							{props.teams.awayTeam.full_name}
						</div>
						<div>{props.teams.gameDate}</div>
						<div className={classes.details}>{props.teams.stadium}</div>
					</div>
					<img
						className={classes.image}
						src={props.teams.awayTeam.logos.large}
					/>{' '}
				</div>
				<Players
					homeId={props.teams.homeTeam.id}
					awayId={props.teams.awayTeam.id}
				/>
				<RecentPlay
					homeId={props.teams.homeTeam.id}
					awayId={props.teams.awayTeam.id}
				/>
				<Injury
					homeId={props.teams.homeTeam.id}
					awayId={props.teams.awayTeam.id}
				/>
			</>
		)
	}

	return <div>{props.teams.loading ? null : loadable()}</div>
}
const mapStateToProps = state => ({
	teams: state.team
})
export default connect(mapStateToProps, null)(MatchUp)
