import React from 'react'
import classes from './Individual.module.css'
const Individual = item => {
	return (
		<div className={classes.indi}>
			<div className={classes.imageContainer}>
				<img src={item.item.headshots.w192xh192} />
			</div>
			<div className={classes.name}>
				{item.item.first_initial_and_last_name}
			</div>
			<div></div>
		</div>
	)
}

export default Individual
