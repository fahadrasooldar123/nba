import React, { useState, useEffect } from 'react'
import classes from './Navbar.module.css'
import axios from 'axios'
import { connect } from 'react-redux'
import { setTeam } from '../../store/actions/index'
const NavBar = ({ setTeam }) => {
	const [teams, setTeams] = useState([])
	const [formValue, setFormValue] = useState('')
	useEffect(() => {
		const fetchData = async () => {
			const data = await axios.get('nba/teams')
			var abbreviations = []
			//loop over the array
			//add each items abbreviation to a global array

			data.data.forEach(item => {
				abbreviations.push({ name: item.abbreviation, id: item.id })
			})
			setTeams([...abbreviations])
		}
		fetchData()
	}, [])
	return (
		<div className={classes.background}>
			<ul className={classes.flexContainer}>
				<li className={classes.logo}>Basket-Ball</li>
				<li>
					<select
						className={classes.select}
						value={formValue}
						onChange={e => {
							setFormValue(e.target.value)
						}}
					>
						<option className={classes.options} value='Please Select'>
							Please Select
						</option>
						{teams.map((item, index) => {
							return (
								<option value={item.id} key={index}>
									{item.name}
								</option>
							)
						})}
					</select>
				</li>
				<li
					className={classes.getMatches}
					onClick={() =>
						//need redux
						//send action to redux
						{
							setTeam(formValue)
						}
					}
				>
					Get Matches
				</li>
			</ul>
		</div>
	)
}
// const mapStateToProps = state => {}
const mapDispatchToProps = { setTeam }
export default connect(null, mapDispatchToProps)(NavBar)
