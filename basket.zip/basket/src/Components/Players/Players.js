import React, { useEffect } from 'react'
import { connect } from 'react-redux'
import { setPlayers } from '../../store/actions/playeractions'
import Individual from '../Individual/Individual'
import classes from './Players.module.css'
const Players = ({ homeId, awayId, setPlayers, players }) => {
	useEffect(() => {
		//fire a new aaction to get the lists of all the players
		setPlayers(homeId, awayId)
	}, [homeId, awayId])
	return (
		<>
			{players.loading ? null : (
				<div className={classes.playerContainer}>
					<div className={classes.header}>
						<h1>STARTING LINEUPS</h1>
					</div>
					<div className={classes.hugeContainer}>
						<div className={classes.smallContainer}>
							{players.homePlayers.slice(0, 5).map((item, index) => (
								<Individual key={index} item={item} />
							))}
						</div>
						<div className={classes.smallContainer}>
							{players.awayPlayers.slice(0, 5).map((item, index) => (
								<Individual key={index} item={item} />
							))}
						</div>
					</div>
				</div>
			)}
		</>
	)
}
const mapDispatchToProps = {
	setPlayers
}
const mapStateToProps = state => ({
	players: state.players
})
export default connect(mapStateToProps, mapDispatchToProps)(Players)
