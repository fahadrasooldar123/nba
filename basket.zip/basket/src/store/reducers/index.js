import { combineReducers } from 'redux'
import teamReducer from './teams'
import playerReducer from './players'
import previousReduccer from './previous'
import injuryReducer from './injury'
const rootReducer = combineReducers({
	//reducers
	team: teamReducer,
	players: playerReducer,
	prev: previousReduccer,
	injury: injuryReducer
})

export default rootReducer
