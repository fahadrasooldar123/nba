import * as actionTypes from '../actions/types'

const initialState = {
	homeInjury: null,
	awayInjury: null,
	loading: true,
	error: false
}

const reducer = (state = initialState, action) => {
	switch (action.type) {
		case actionTypes.GET_INJURY: {
			return {
				...initialState,
				homeInjury: action.Hdata,
				awayInjury: action.Adata,
				loading: false,
				error: false
			}
		}
		default: {
			return state
		}
	}
}
export default reducer
