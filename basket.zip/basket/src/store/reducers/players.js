import * as actionTypes from '../actions/types'

const initialState = {
	homePlayers: null,
	awayPlayers: null,
	loading: true,
	error: false
}

const reducer = (state = initialState, action) => {
	switch (action.type) {
		case actionTypes.SET_PLAYERS: {
			return {
				...initialState,
				homePlayers: action.homeData,
				awayPlayers: action.awayData,
				loading: false,
				error: false
			}
		}
		default: {
			return state
		}
	}
}
export default reducer
