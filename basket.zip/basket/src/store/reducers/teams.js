import * as actionTypes from '../actions/types'

const initialState = {
	stadium: null,
	homeTeam: null,
	awayTeam: null,
	error: false,
	loading: true,
	gameDate: null,
	colours: null
}

const reducer = (state = initialState, action) => {
	switch (action.type) {
		case actionTypes.SET_DATA: {
			return {
				...initialState,
				stadium: action.data.stadium,
				colours: action.data.colours,
				error: false,
				loading: false,
				gameDate: action.data.game_date,
				awayTeam: action.data.away_team,
				homeTeam: action.data.home_team
			}
		}
		default: {
			return state
		}
	}
}
export default reducer
