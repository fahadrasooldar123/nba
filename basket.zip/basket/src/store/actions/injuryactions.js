import * as actionTypes from './types'
import axios from 'axios'
const setInjury = (Hdata, Adata) => {
	return {
		type: actionTypes.GET_INJURY,
		Hdata,
		Adata
	}
}

export const getInjury = (homeTeam, awayTeam) => {
	return async dispatch => {
		try {
			const Hdata = await axios.get(`nba/teams/${homeTeam}/injuries`)
			const Adata = await axios.get(`nba/teams/${awayTeam}/injuries`)

			dispatch(setInjury(Hdata.data, Adata.data))
		} catch (error) {
			console.log('Error')
		}
	}
}
