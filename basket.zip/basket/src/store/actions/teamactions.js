import * as actionTypes from './types'
import axios from 'axios'
export const setData = data => {
	return {
		type: actionTypes.SET_DATA,
		data
	}
}

export const setTeam = teamCode => {
	return async dispatch => {
		try {
			const data = await axios.get(`nba/events/${teamCode}`)

			dispatch(setData(data.data))
		} catch (error) {
			console.log('Error')
		}
	}
}

