import * as actionTypes from './types'
import axios from 'axios'
const setPrev = (homePrevData, awayPrevData) => {
	const HPD = homePrevData.data
	const APD = awayPrevData.data
	return {
		type: actionTypes.GET_PREV,
		HPD,
		APD
	}
}
export const getPrev = (homeId, awayId) => {
	console.log(homeId)
	console.log(awayId)
	return async dispatch => {
		try {
			const homePrevData = await axios.get(
				`nba/teams/${homeId}/events/previous`
			)
			const awayPrevData = await axios.get(`
            nba/teams/${awayId}/events/previous`)
			
			dispatch(setPrev(homePrevData, awayPrevData))
		} catch (error) {
			console.log('Error')
		}
	}
}
