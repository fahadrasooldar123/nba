import * as actionTypes from './types'
import axios from 'axios'
const setAllPlayers = (homePlayers, awayPlayers) => {
	const homeData = homePlayers.data
	const awayData = awayPlayers.data
	return {
		type: actionTypes.SET_PLAYERS,
		homeData,
		awayData
	}
}
export const setPlayers = (homeId, awayId) => {
	return async dispatch => {
		const homePlayers = await axios.get(`nba/teams/${homeId}/players`)
		const awayPlayers = await axios.get(`nba/teams/${awayId}/players`)
		//call the backend
		//dispatch another action
		dispatch(setAllPlayers(homePlayers, awayPlayers))
	}
}
