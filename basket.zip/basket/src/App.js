import './App.css'
import MatchUp from './Components/MatchUp/MatchUp'
import NavBar from './Components/NavBar/NavBar'
import Players from './Components/Players/Players'

function App() {
	return (
		<div className='App'>
			<NavBar />
			<MatchUp />
		</div>
	)
}

export default App
